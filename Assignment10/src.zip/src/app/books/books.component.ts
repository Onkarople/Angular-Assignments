import { Component } from '@angular/core';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent {

  public bookarry: string[]=["AngularDocumentaion","BigData book for beginers","Hello Android","Machine learning : A new Way"];
  

}
